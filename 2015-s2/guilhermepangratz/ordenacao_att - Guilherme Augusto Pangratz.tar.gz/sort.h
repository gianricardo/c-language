#include "arquivo.h" /**Incluido aqui o arquivo.h pelos headers que estão lá*/

void quicksort(double *vetor, long int esq, long int dir);/**Metodo de ordenação QuickSort*/